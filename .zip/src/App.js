import { GlobalStyles } from './app.styled';
import Home from './Containers/Home';
import "./App.css";

function App() {
  return (
    <div className="App">
      <GlobalStyles />
      <Home />
    </div>
  );
}

export default App;
